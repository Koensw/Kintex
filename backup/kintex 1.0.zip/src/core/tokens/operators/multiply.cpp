#include <iostream>
#include <typeinfo>

#include "operators.h"
#include "../operands/operands.h"
#include "../../processor.h"

using namespace kintex;

MultiplyOperator *MultiplyOperator::create(Processor &p){
    //check if match:
    //no: return NULL
    if(p.getChar() != op[0]) return nullptr;

    //yes: goto next char
    p.nextChar();
    
    //create the operator
    return new MultiplyOperator(p.getPrevExpression(), p.getNextExpression());
}

Value MultiplyOperator::result(){
    //if right hand is float convert lefthand to float too
    Value ret = children[0]->result();
    if(typeid(*children[1]->result()) == typeid(FloatingPoint) && typeid(*ret) == typeid(Integer)){
        ret = FloatingPoint(dynamic_cast<Integer&>(*ret));
    }
    
    *ret *= *children[1]->result();
    return ret;
}