#include "operand.h"

using namespace kintex;

Value Operand::result(){ 
    return *this;
}