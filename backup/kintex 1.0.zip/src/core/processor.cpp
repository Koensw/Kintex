#include <vector>
#include <cstddef>
#include <typeinfo>
#include <utility>
#include <exception>
#include <memory>

#include "processor.h"
#include "token.h"
#include "exception.h"
#include "interpreter.h"
#include "level.h"
#include "tokens/operands/operands.h"
#include "tokens/operators/operators.h"
#include "tokens/names/names.h"


using namespace kintex;
using std::vector;

/* Next expression read */
Expression Processor::getNextExpression(){
    //check if token left
    if(!isExpressionLeft()){
        //if no token left return previous token
        //--> the 'no' token has the lowest precedence
        return getPrevExpression();
    }

    //pass all spaces
    if(getChar()==' '){
		char nextCharacter = nextChar();
        while(nextCharacter==' ') nextCharacter = nextChar();
    }
    
    //save level and begin with token under
    TokenList::iterator saveLevel = level;
    resetLevel();
   
    while(level!=tokenList.end()){
        //search for next token if level has higher precedence
        if((level->getAssoc() == Level::Assoc::LEFT && level->getIndex() > saveLevel->getIndex()) 
            || (level->getAssoc() == Level::Assoc::RIGHT && level->getIndex() >= saveLevel->getIndex())){
            for(Level::iterator iter = level->begin(); iter < level->end(); ++iter){
		        //DEBUG:
		        //std::cout << " *> " << getChar() << " - " << typeid(**iter).name() << std::endl;
		        //save current positions
		        std::string::iterator saveCurrent = current;

                //create token
                Token* tok;
                tok = (*iter)->create(*this);

                //wait until instance succeeded
                if(tok != nullptr){
					//build new expression or get old if operand points to the same
					Expression tokenExpr;
					if(tok == &(**iter)) tokenExpr = *iter; //get old expression if the same (else memory errors!)
					else tokenExpr = Expression(tok); //create an expression (smart pointer) from the token

					//add token to level if needed
                    if((*iter)->getAddLevelIndex() != 0){
                        for(TokenList::LevelList::iterator it = getTokenList().begin(); it != getTokenList().end(); ++it){
                            if(it->getIndex() == (*iter)->getAddLevelIndex()) it->addToken(tokenExpr);
                        }
                    }
                    
                    //calculate default positions
                    Line::Positions pos = std::make_pair(saveCurrent-line->code.begin(), current-line->code.begin());
                    //set positions to first and last children if possible
                    if(!tokenExpr->children.empty()){
						if(tokenExpr->children.front()->positions.first < pos.first) pos.first = tokenExpr->children.front()->positions.first;
						if(tokenExpr->children.back()->positions.second > pos.second) pos.second = tokenExpr->children.back()->positions.second;
					}
                    
                    //set line and positions
                    tokenExpr->line = line;
                    tokenExpr->positions = pos;

                    //add expression to previous expression stack
                    prevExpr.push(tokenExpr);

                    //reset level and try to match next token that has a higher precedency
                    level = saveLevel;
                    return getNextExpression();
                }
            }
        }

        //increase level
        ++level;
    }
    
    //check if on lowest level no token could be matched --> then the token is unknown
    if(saveLevel->getIndex()==0) {
        throw UnknownToken(*this);
    }

    //reset level and return previous expression if nothing higher can be matched 
    level = saveLevel;
    return getPrevExpression();
}

/* Prev expression read */
Expression Processor::getPrevExpression(){
    //check if there is a token, else throw an exception
    if(prevExpr.empty()){ 
        throw MissingToken(*this);
    }

	//get return expr
    Expression returnExpr = prevExpr.top();
  	prevExpr.pop();  
  	
    //loop through all children and set parent
    for(std::vector<Expression>::iterator child_iter = returnExpr->children.begin(); child_iter < returnExpr->children.end(); ++child_iter){
        (*child_iter)->parent = &*returnExpr;
    } 

	//return expression
    return returnExpr;
}

/* Reset level (after all tokens had been added)
*/
void Processor::resetLevel(){
    level = tokenList.begin();
}

/* Get the linked interpreter (used by childs)
*/
TokenList &Processor::getTokenList() const {
    return tokenList;
}

/* On finish from Processor work */
void Processor::finish(){
    if(isPrevExpressionLeft()) throw LeftToken(*this, getPrevExpression());
    else if(isExpressionLeft()) throw LeftToken(*this, getNextExpression());
}

/* Copy used by copy-constructor and assignment */
void Processor::copy(const Processor &p){
    //copy normal members
    line = p.line;
    prevExpr = p.prevExpr;
    level = p.level;
    //tokens = p.tokens;
    //copy Line and pointer
    line = p.line;
    positions = p.positions;
    
    //copy iterator as iterator for new tokens
    current = p.current;
}

