#ifndef KINTEX_OPERATORS_H
#define KINTEX_OPERATORS_H 

#include "../../interpreter.h"
#include "../../operator.h"
#include "../operands/operands.h"
#include "../../operand.h"
//TODO: necessary include
#include "../../../kintex.h"

namespace kintex{
    class Processor;

    /* Default operators */
    class AddOperator: public BinaryOperator{
        public:
            /* Default constructor */
            AddOperator(): BinaryOperator("+", Expression(Integer().clone()), Expression(Integer().clone())) {}
            /* Create constructor */
            AddOperator(Expression lhs, Expression rhs): BinaryOperator("+", lhs, rhs) {}
            /* Result operator */
            Value result();
            /* Clone operator */
            AddOperator *clone() const{ return new AddOperator(*this);}
            /* Create operator */
            AddOperator *create(Processor&);
            /* Name function */
            std::string getName() const{ return "addition";}
    };
    class SubtractOperator: public BinaryOperator{
        public:
            /* Default constructor */
            SubtractOperator(): BinaryOperator("-", Expression(Integer().clone()), Expression(Integer().clone())) {}
            /* Create constructor */
            SubtractOperator(Expression lhs, Expression rhs): BinaryOperator("-", lhs, rhs) {}
            /* Result operator */
            Value result();
            /* Clone operator */
            SubtractOperator *clone() const{ return new SubtractOperator(*this);}
            /* Create operator */
            SubtractOperator *create(Processor&);
            /* Name function */
            std::string getName() const{ return "subtract";}
    };
    class MultiplyOperator: public BinaryOperator{
        public:
            /* Default constructor */
            MultiplyOperator(): BinaryOperator("*", Expression(Integer().clone()), Expression(Integer().clone())) {}
            /* Createconstructor */
            MultiplyOperator(Expression lhs, Expression rhs): BinaryOperator("*", lhs, rhs) {}
            /* Result operator */
            Value result();
            /* Clone operator */
            MultiplyOperator *clone() const{ return new MultiplyOperator(*this);}
            /* Create operator */
            MultiplyOperator *create(Processor&);
            /* Name function */
            std::string getName() const{ return "multiplication";}
    };
    class DivideOperator: public BinaryOperator{
        public:
            /* Default constructor */
            DivideOperator(): BinaryOperator("/", Expression(Integer().clone()), Expression(Integer().clone())) {}
            /* Create constructor */
            DivideOperator(Expression lhs, Expression rhs): BinaryOperator("/", lhs, rhs) {}
            /* Result operator */
            Value result();
            /* Clone operator */
            DivideOperator *clone() const{ return new DivideOperator(*this);}
            /* Create operator */
            DivideOperator *create(Processor&);
            /* Name function */
            std::string getName() const{ return "divide";}
    };
	/* Set operator (=) a bit special because it only works on variables (and functions) */
	class SetOperator: public BinaryOperator{
        public:
            /* Default constructor */
            SetOperator(): BinaryOperator("=", Expression(Integer().clone()), Expression(Integer().clone())) {}
            /* Create constructor */
            SetOperator(Expression lhs, Expression rhs): BinaryOperator("=", lhs, rhs) {}
			/* Special display operator */
            //FIXME: use this ??
			//std::ostream &display(std::ostream &) const;
            /* Result operator */
            Value result();
            /* Clone operator */
            SetOperator *clone() const{ return new SetOperator(*this);}
            /* Create operator */
            SetOperator *create(Processor&);
            /* Name function */
            std::string getName() const{ return "assign";}
    };

    /* Exponentation operator */
   class ExponentOperator: public BinaryOperator{
        public:
            /* Default constructor */
            ExponentOperator(): BinaryOperator("^", Expression(Integer().clone()), Expression(Integer().clone())) {}
            /* Create constructor */
            ExponentOperator(Expression lhs, Expression rhs): BinaryOperator("^", lhs, rhs) {}
            /* Result operator */
            Value result();
            /* Clone operator */
            ExponentOperator *clone() const{ return new ExponentOperator(*this);}
            /* Create operator */
            ExponentOperator *create(Processor&);
            /* Name function */
            std::string getName() const{ return "power";}
    };

    /* Parentheses (special operator to combine tokens) */
    class ParenthesesOperator: public UnaryOperator{
        public:
            /* Default constructor */
            ParenthesesOperator(): UnaryOperator("(", Expression(Integer().clone())) {}
            /* Create constructor */
            ParenthesesOperator(Expression expr): UnaryOperator("(", expr) {}
            /* Result operator */
            Value result();
            /* Display operator */
            std::ostream &display(std::ostream &) const;
            /* Clone operator */
            ParenthesesOperator *clone() const{ return new ParenthesesOperator(*this);}
            /* Create operator */
            ParenthesesOperator *create(Processor&);
            /* Overriding special contents operator to return the child */
            Token &getContents() { 
                return children[0]->getContents();
            }
            /* Name function */
            std::string getName() const{ return children[0]->getName();}
    };

    /* Brackets (special operator to combine statements) */
    class BracketsOperator: public Operator{
        public:
            /* Default constructor */
            BracketsOperator(): Operator("{") {}
            /* Create constructor */
            BracketsOperator(std::vector<Expression> statements): Operator("{") { children = statements; }
            /* Result operator */
            Value result();
            /* Display operator */
            std::ostream &display(std::ostream &) const;
            /* Clone operator */
            BracketsOperator *clone() const{ return new BracketsOperator(*this);}
            /* Create operator */
            BracketsOperator *create(Processor&);
            /* Overriding special contents operator to return the child */
            Token &getContents() { 
                return children[0]->getContents();
            }
            /* Name function */
            std::string getName() const{ return children[0]->getName();}
    };


}

#endif
