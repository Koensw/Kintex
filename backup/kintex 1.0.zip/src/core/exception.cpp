#include <typeinfo>

#include "exception.h"
#include "processor.h"
#include "interpreter.h"
#include "name.h"

using namespace kintex;

/* Syntax error*/
std::string SyntaxError::getTokenString() const{
    std::string ret;
    //check if a file is attached (then show more info)
    if(!proc.line->file.empty()){
        ret += proc.line->file;
        ret += "(";
        std::ostringstream tmp;
        tmp << proc.line->number;
        ret += tmp.str();
        ret += "): ";
    }
    ret += proc.line->code;
    return ret;
}
std::string SyntaxError::getErrorPointerString() const{
    std::string ret;
    ret += std::string((proc.current - proc.line->code.begin()) + (getTokenString().size() - proc.line->code.size()), ' ');
    ret += '^';
    return ret;
}

/* Left token */
std::string LeftToken::getErrorPointerString() const{
    std::string ret;
    ret += std::string(leftExpression->positions.first + (getTokenString().size() - proc.line->code.size()), ' ');
    ret += std::string(leftExpression->positions.second - leftExpression->positions.first, '^');
    return ret;
}

/* ExecError */
std::string ExecError::getTokenString() const{
    std::string ret;
    //check if a file is attached (then show more info)
    if(!error->line->file.empty()){
        ret += error->line->file;
        ret += "(";
        std::ostringstream tmp;
        tmp << error->line->number;
        ret += tmp.str();
        ret += "): ";
    }
    ret += error->line->code;
    return ret;
}
std::string ExecError::getErrorPointerString() const{
	std::string ret;
    ret += std::string(error->positions.first + (getTokenString().size() - error->line->code.size()), ' ');
    ret += std::string(error->positions.second - error->positions.first, '^');
                
    return ret;
}

/* UnsupportedOperation */
UnsupportedOperation::UnsupportedOperation(const Token &child): ExecError(child.getParent()->clone()) {
    //saving result of all children (do it now, because after construction, the object should be constant)
    for(std::vector<Expression>::iterator iter = error->children.begin(); iter < error->children.end(); ++iter){
        children.push_back((*iter)->result());
    }
} 
std::string UnsupportedOperation::what() const throw(){
	std::string ret("Cannot do operation ");
    //convert parent to operator
    ret += error->getName();
    ret += " on ";
                
    //loop through all childs
    for(std::vector<Expression>::const_iterator iter = children.begin(); iter < children.end(); ++iter){
    	ret += (*iter)->getName();
        if(iter+2 < children.end()) ret += ", ";
        else if(iter+1 < children.end()) ret += " and ";
	}
    ret += ".";
                
    return ret;
}

/* UndefinedVariable */
std::string UndefinedVariable::what() const throw(){
    std::string ret("Variable ");
    
    ret += "'";
    //cast to name and get value (always succeeds, because should be a variable)
    ret += dynamic_cast<const Name&>(*error).name;
    ret += "' is used, before it is defined!";
    
    return ret;
}
