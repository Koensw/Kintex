#include <typeinfo>

#include "operators.h"
#include "../names/names.h"
#include "../../processor.h"
#include "../../exception.h"
#include "../../token.h"

using namespace kintex;

SetOperator *SetOperator::create(Processor &p){
    //check if match:
    //no: return NULL
    if(p.getChar() != op[0]) return nullptr;

    //yes: goto next char and create the operator
    p.nextChar();
    return new SetOperator(p.getPrevExpression(), p.getNextExpression());
}

Value SetOperator::result(){
    //check if ret is a variable -> else throw UnsupportedOperation
    if(typeid(children[0]->getContents()) != typeid(Variable)) throw UnsupportedOperation(*children[0]);
    else{
        //cast token to name (always succeed, because it is a variable)
        Name &ret(dynamic_cast<Name&>(children[0]->getContents()));
        
        ret = *(children[1]->result());
        return ret.result();
    }
}
