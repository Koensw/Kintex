#include <algorithm> 
#include <functional>
#include <utility>
#include <tuple>

#include "operators.h"
#include "../operands/operands.h"
#include "../../processor.h"

using namespace kintex;

//TODO: better integration with interpreter
BracketsOperator *BracketsOperator::create(Processor &p){
    //check if match
    //no: return;
    if(p.getChar() != op[0]) return nullptr;
	//build lines that should be read 	
	typedef std::vector<std::tuple<std::shared_ptr<Line>, size_t, size_t>> Lines;
	Lines lines;
	
	//save current place of iterator;
	std::string::iterator start = p.current + 1;
	
    //read first closing tag (in current line)
    int cnt = 1;
    int length = 0;
	p.nextChar();
    while(p.isExpressionLeft()){
        if(p.getChar() == '{') cnt++;
        if(p.getChar() == '}') cnt--;
		p.nextChar();
		
		//stop if corresponding } is reached
		if(cnt == 0) break;
        length++;
    }
	//add first line
	lines.push_back(make_tuple(p.line, start - p.line->code.begin(), length));
	
	//if not finished yet with searching, build new lines until corresponding } is found
	length = 1;
	while(cnt!=0){
		//get previous line
		std::shared_ptr<Line> prevLine = std::get<0>(lines.back());
		
		//build new line of code
		Line *li = new Line;
		li->file = prevLine->file;
		li->code = prevLine->totalCode->substr(prevLine->totalCodeEnd + 1, prevLine->totalCode->find('\n', prevLine->totalCodeEnd + 1) - prevLine->totalCodeEnd - 1);
		li->number = prevLine->number+1;
		li->totalCode = prevLine->totalCode;
		li->totalCodeBegin = prevLine->totalCodeEnd + 1;
		li->totalCodeEnd = li->totalCodeBegin + li->code.size();
		
		//pass to pointer
		std::shared_ptr<Line> line_pointer(li);
				
		//search for finish
		size_t searchPos = -1;
		while((searchPos = li->code.find_first_of("{}", ++searchPos)) != std::string::npos){
			if(li->code[searchPos] == '{') ++cnt;
			if(li->code[searchPos] == '}') --cnt;
			//if corresponding } is found add to lines and break
			if(cnt == 0){
				//add to lines
				lines.push_back(make_tuple(line_pointer, 0, searchPos));
				//set new line for processor
				p.line = line_pointer;
				p.positions = std::make_pair(searchPos + 1, line_pointer->code.size());
				p.current = line_pointer->code.begin() + p.positions.first;
				break;
			}
		}
		
		//if not already finished add to lines
		if(cnt != 0){
			//add to lines
			lines.push_back(make_tuple(line_pointer, 0, line_pointer->code.size()));
		}
	}
	
	//build statementslist
	std::vector<Expression> statementList;
	
	//loop through all lines
	for(Lines::iterator iter = lines.begin(); iter < lines.end(); ++iter){		
		//process all statements on this line
		size_t begin = std::get<1>(*iter);
		size_t end = begin + std::get<2>(*iter);
		size_t prev(begin), current(begin);
		while(current != end){
			//find next end of statement
			if((current = std::get<0>(*iter)->code.find_first_of(betweenChars, current)) == std::string::npos || current > end) current = end;  

			//calculate positions
			Line::Positions pos = std::make_pair(prev, current);
			
			//buid processor for this statement
			Processor proc(p.getTokenList(), std::get<0>(*iter), pos);

			//check if expression contains tokens
			if(proc.isExpressionLeft()){
				statementList.push_back(proc.getNextExpression());
			}
			//finish processor
			proc.finish();
			
			//jump forward the lines that are handled by the other brackets-operator
			int loop = proc.line->number - std::get<0>(*iter)->number;
			iter += loop;
			
			//skip 'between' token
			if(current != end) prev = ++current;
		}
	}

    return new BracketsOperator(statementList);
}

Value BracketsOperator::result(){
    //return result of last statement if exists (else return void)
    if(!children.empty()) {
        //execute all statements (but not the last one)
        for(std::vector<Expression>::iterator iter = children.begin(); iter < children.end()-1; ++iter){
            (*iter)->result();
        }
        //set parent of child to parent of brackets operator (because this brackets operator should not exist for the user!)
        children[0]->parent = getParent();
        //return result last statement
        return children.back()->result();
    }else{
        //return an empty void (parent set to this parent)
        Value empty(new Void);
        empty->parent = parent;
        return empty;
    }
}

/* Special display operator */
std::ostream &BracketsOperator::display(std::ostream &out) const{
    std::vector<Expression>::const_iterator iter = children.begin();
    out << "{";
    for(; iter < children.end() - 1; ++iter){
        out << *iter << ";"; //<< std::endl;
    }
    out << *iter << "}";
    return out;
}
