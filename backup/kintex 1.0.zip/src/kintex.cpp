#include <algorithm>
#include <string>
#include <iostream>
#include <vector>
#include <iterator>
#include <utility>
#include <memory>
#include <cctype>

#include "kintex.h"
#include "core/exception.h"
#include "core/interpreter.h"
#include "core/token.h"
#include "core/processor.h"

using namespace kintex;

/* 
 * Implementation of the interpreter: the communication class with the programmer-user
 */

/* Parse a string */
Interpreter::StatementList Interpreter::parse(std::string str, std::string name){
    //convert to iterators and parse
    return parse(str.begin(), str.end(), name);
}

/* Parse a input stream (like standard input or a file) */
Interpreter::StatementList Interpreter::parse(std::istream &in, std::string name){
    //build iterators
    std::istream_iterator<char> begin(in);
    std::istream_iterator<char> end;
    //convert to string (because an random-access iterator is needed)
    std::string parseString(begin, end);
    //parse string
    return parse(parseString, name);
}

/* Parse one line from an input stream */
Interpreter::StatementList Interpreter::parseLine(std::istream &in, std::string name){
    std::string parseString;
    //use getline to get the string
    std::getline(in, parseString);
    //parse string
    return parse(parseString, name);
}

/* Private parser used by other kintex parsers */
template<typename Iter> Interpreter::StatementList Interpreter::parse(Iter begin, Iter end, std::string file_name){
    //return statementlist
    StatementList ret;
    
    //create a line of code
    Line *line = new Line;
    line->file = file_name;
    line->code = std::string(begin, find(begin, end, '\n'));
    line->number = 1;
	line->totalCode = std::shared_ptr<std::string>(new std::string(begin, end));
	line->totalCodeBegin = 0;
	line->totalCodeEnd = line->code.size();
	
    //pass control to shared_ptr
    std::shared_ptr<Line> line_pointer(line);
	    
    //check if brackets are valid
    if(std::count(line->totalCode->begin(), line->totalCode->end(), '{') != std::count(line->totalCode->begin(), line->totalCode->end(), '}')) throw BracketError();
    
    //read all individual statements
    Iter prev(begin), current(begin);
    while(current != end){
        //find next end of statement not in bracket level
        do{  
            //search first between char
            current = find_first_of(current, end, betweenChars.begin(), betweenChars.end());
            
            //increase if end has not been reached
            if(current==end || ++current==end) break;
        }while(std::count(prev, current, '{') != std::count(prev, current, '}'));
        //goto prev position if end token is found (that should not be processed)
        if(*(current-1) == ';' || *(current-1) == '\n') --current;

        //find positions of current processor
		Line::Positions pos;
		if(static_cast<size_t>(current-begin) >= line_pointer->code.size()) pos = std::make_pair(prev-begin, line_pointer->code.size());
        else pos = std::make_pair(prev-begin, current-begin);
        
        //build processor for this statement
        Processor proc(tokenList, line_pointer, pos);
        //check if expression contains tokens
        if(proc.isExpressionLeft()){
		    Expression expr = proc.getNextExpression();
            ret.push_back(expr);
        }
		//finish processor
		proc.finish();
		
		//get line
		line_pointer = proc.line;
        
        //check if token could be skipped or a new line could be created
        if(current!=end){
            //skip 'between' token
            prev = ++current;
            //check if a new line had been found
            if(*(current-1) == '\n'){
                //set begin
                begin = current;
                
                //build new line of code
                Line *line = new Line;
                line->file = file_name;
                line->code = std::string(begin, find(begin, end, '\n'));
                line->number = line_pointer->number+1;
				line->totalCode = line_pointer->totalCode;
				line->totalCodeBegin = line_pointer->totalCodeEnd + 1;
				line->totalCodeEnd = line->totalCodeBegin + line->code.size();
				
                //pass control to shared_ptr
                line_pointer = std::shared_ptr<Line>(line);
            } 
        }
    }
    return ret;
}