#include <vector>

/* WARNING: all includes from the library are temporarily done by default_library */
#include "default_library.h"

using namespace kintex;

/*
 *  Prints the result of the argument to std-out
 *  Returns: void
 */
Value PrintFunction::operator()(std::vector<Expression> values){
    std::cout << values[0]->result() << std::endl;
    return Void(getParent());
}

/*
 *  Prints the expression of the argument to std-out
 *  Returns: void
 */
Value PrintExpressionFunction::operator()(std::vector<Expression> values){
    std::cout << values[0] << std::endl;
    return Void(getParent());
}

/*
 * FIXME: define this function in kin language
 *  Computes the square root of an expression
 *  Returns: square root
 */
Value SquareRootFunction::operator()(std::vector<Expression> values){
    Value result(values[0]->result());
    Value power(FloatingPoint(0.5));
    result->pow(*power);
    return result;
}