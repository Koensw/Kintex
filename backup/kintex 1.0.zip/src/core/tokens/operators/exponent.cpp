#include <iostream>
#include <typeinfo>

#include "operators.h"
#include "../operands/operands.h"
#include "../../processor.h"

using namespace kintex;

ExponentOperator *ExponentOperator::create(Processor &p){
    //check if match:
    //no: return NULL
    if(p.getChar() != op[0]) return nullptr;

    //yes: goto next char and create the operator
    p.nextChar();

    //build new operator
    return new ExponentOperator(p.getPrevExpression(), p.getNextExpression());
}

Value ExponentOperator::result(){
    //if right hand is float convert lefthand to float too
    Value ret = children[0]->result();
    if(typeid(*children[1]->result()) == typeid(FloatingPoint) && typeid(*ret) == typeid(Integer)){
        ret = FloatingPoint(dynamic_cast<Integer&>(*ret));
    }

    *ret = ret->pow(*children[1]->result());
    return ret;
}
