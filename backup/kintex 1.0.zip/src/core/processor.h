#ifndef KINTEX_PROCESSOR_H
#define KINTEX_PROCESSOR_H

#include <string>
#include <map>
#include <vector>
#include <stack>
#include <iterator>
#include <utility>
#include <memory>
#include <cctype>
#include <iostream>

#include "interpreter.h"
#include "token.h"
#include "level.h"

namespace kintex{
    class Expression;
    
    //Processor
    class Processor{
        public:
            /* all syntax errors are friends */
            friend class SyntaxError;
            friend class UnknownToken;
            friend class MissingToken;
            friend class LeftToken;
            
            /* FIXME: all tokens that mess with lines are friends; TODO: let configuration of lines be done by processor */
            friend class ParenthesesOperator;
            friend class BracketsOperator;
            friend class Interpreter;
            friend class FunctionCreator;
            
            /** Default constructor */
            Processor(TokenList &list, std::shared_ptr<Line> givenLine, Line::Positions givenPos): 
            tokenList(list), level(list.begin()), line(givenLine), positions(givenPos) {
                //pass all begin and end spaces
                while(isspace(line->code[positions.first])) ++positions.first;
                while(isspace(line->code[positions.second-1]) && positions.first != positions.second-1) --positions.second;
                
                //set current to start position
                current = line->code.begin() + positions.first;
            }

            /** Copy constructor and assignment operator to copy iterators good */
            Processor(const Processor &p): tokenList(p.tokenList){
                copy(p);
            }
            Processor operator=(const Processor &p){
                copy(p);
                return *this;
            }

            /** Get current and next character */
            char getChar() const{
                //return space if no token left (WARN: space can never be matced!)
                if(!isExpressionLeft()) return ' ';
                return *current; 
            }
            char nextChar(){
                //return space if no token left (WARN: space can never be matched!)
                if(!isExpressionLeft()) return ' ';
                //increase pointer
                *(++current);
                //return now current char
                return getChar();
            }
            /** Lookup next chars without going to it *
             * WARNING: read next char if you got a real match
             */
            char lookNextChar(int next = 1) const{
                std::string::iterator look = current;
                look += next; 
                return *look;
            }

            /** Get next and previous expressions (and check if expressions left), now support parents */
            Expression getNextExpression();
            Expression getPrevExpression();

			/** Check if expressions left */
			bool isExpressionLeft(unsigned int next = 0) const{
				return (static_cast<size_t>(current-line->code.begin())+next < positions.second);
			}
            bool isPrevExpressionLeft() const{
                return !prevExpr.empty();
            }

            /** Reset level (after all tokens had been added) */
            void resetLevel();
            /** This function should be called when the Processor should be finished with his work
             * --> throws an exception when there are expressions left
             */
            void finish();
			
            /** Get the linked tokenlist (used by childs)
             */
            TokenList &getTokenList() const;

        private:
            /* Copy used by copy-constructor and assignment */
            void copy(const Processor &p);
            /* List of tokens and iterator */
            TokenList &tokenList;
            TokenList::iterator level;
            
            /* List of not assigned expressions */
            std::stack<Expression> prevExpr;
            
			/* Hold current position */
			std::string::iterator current;
			
            /* Line and position in that line */
            std::shared_ptr<Line> line;
            Line::Positions positions;
			
    };
}

#endif
