#ifndef KINTEX_DEFAULT_LIBRARY_H
#define KINTEX_DEFAULT_LIBRARY_H 

#include <vector>

#include "../src/core/interpreter.h"
#include "../src/core/tokens/names/names.h"
#include "../src/core/tokens/operands/operands.h"

/**
 * Define all custom functions
 */

//print result expression to std-out
class PrintFunction: public kintex::FunctionBase{
public:
    PrintFunction(): kintex::FunctionBase("print", 1) {}
    PrintFunction *clone() const{ return new PrintFunction(*this); }
    
    kintex::Value operator()(std::vector<kintex::Expression>);
};

//print expression to std-out
class PrintExpressionFunction: public kintex::FunctionBase{
public:
    /* FIXME: better name */
    PrintExpressionFunction(): kintex::FunctionBase("show", 1) {}
    PrintExpressionFunction *clone() const{ return new PrintExpressionFunction(*this); }
    
    kintex::Value operator()(std::vector<kintex::Expression>);
};

//computes square root of given number
class SquareRootFunction: public kintex::FunctionBase{
public:
    SquareRootFunction(): kintex::FunctionBase("sqrt", 1) {}
    SquareRootFunction *clone() const{ return new SquareRootFunction(*this); }
    
    kintex::Value operator()(std::vector<kintex::Expression>);
};

#endif