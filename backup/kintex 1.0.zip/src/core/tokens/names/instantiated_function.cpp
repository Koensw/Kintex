#include <iostream>
#include <cctype>

#include "names.h"

using namespace kintex;

/* Return result function with argument values set */
Value InstantiatedFunction::result(){
    //set correct parent
    func->parent = getParent();
    //execute bound function with argument values
    return (*func)(argumentValues);
}

/* Display function with arguments */
std::ostream &InstantiatedFunction::display(std::ostream &out) const{
    out << func->name;
    out << "(";
    std::vector<Expression>::const_iterator argValIter = argumentValues.begin();
    for(;argValIter < argumentValues.end(); ++argValIter){
        out << *argValIter;
        if(argValIter+1 != argumentValues.end()) out << ",";
    }
    out << ")";
    return out;
}