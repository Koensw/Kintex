#include <algorithm> 
#include <functional>
#include <utility>

#include "../../token.h"
#include "operators.h"
#include "../operands/operands.h"
#include "../../processor.h"

using namespace kintex;

//TODO: better integration with Processor
ParenthesesOperator *ParenthesesOperator::create(Processor &p){
    //check if match
    //no: return;
    if(p.getChar() != '(' && p.getChar() != ',') return nullptr;
    //yes search closing tag or end of expression
    int cnt = 1;
    int length = 0;
    p.nextChar();
    while(p.isExpressionLeft() && !(p.getChar() == ')' && cnt == 1) && !(p.getChar() == ',' && cnt == 1)){
        if(p.getChar() == '(') cnt++;
        else if(p.getChar() == ')') cnt--;
        ++length;
        p.nextChar();
    }
    //goto next char and set end one character earlier if it is a ')', else just use the currenct character
    int end;
    if(p.getChar() == ')'){
        p.nextChar();
        end = p.current-p.line->code.begin()-1;
    }else end = p.current-p.line->code.begin();

    //calculate positions
    Line::Positions pos = std::make_pair(end-length, end);    

	//check if brackets are valid
    if(std::count(p.line->code.begin() + pos.first, p.line->code.begin() + pos.second, '{') > 0 || std::count(p.line->code.begin() + pos.first, p.line->code.begin() + pos.second, '}') > 0){
		throw ParseError(p, "Invalid use of brackets inside parentheses (replace by brackets).");
	}
	
    //build a new processor and process the found string
    Processor proc(p.getTokenList(), p.line, pos);

    //execute
    Expression expr = proc.getNextExpression();
    proc.finish();
    
    //return operator
    return new ParenthesesOperator(expr);
}

Value ParenthesesOperator::result(){
    //set parent of child to parent of parentheses operator (because this parentheses operator should not exist for the user!)
    children[0]->parent = getParent();
    //simply return containing expression
    return children[0]->result();
}

/* Special display operator */
std::ostream &ParenthesesOperator::display(std::ostream &out) const{
    out << children[0];
    return out;
}
